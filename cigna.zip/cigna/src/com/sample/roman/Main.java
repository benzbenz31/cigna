package com.sample.roman;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Main {
	
	private static Map<String, Integer> romanNumber = null;
	private static char ADD = '+';
	
	public static void main(String[] args) {
		
		List<String> allInputs = readFileInput(args[0]);
		
		for (String sample : allInputs) {
			char token;
			retrieveAllRomanNumber();
			List<Integer> leftNumber = new ArrayList<Integer>();
			List<Integer> rightNumber = new ArrayList<Integer>();
			List<String> leftString = new ArrayList<String>();
			List<String> rightString = new ArrayList<String>();
			
			boolean isLeft = true;
			int index = 0;
			
			while (index < sample.length()) {
				token = sample.charAt(index);
				if (isOperator(token)) {
					isLeft = false;
					index++;
					continue;
				}
				
				Integer numberValue = romanNumber.get(String.valueOf(token));
				
				if (isLeft) {
					leftNumber.add(numberValue);
					leftString.add(String.valueOf(token));
				} else {
					rightNumber.add(numberValue);
					rightString.add(String.valueOf(token));
				}
				
				index++;
			}
			
			Integer left = convertToRealValue(leftNumber);
			Integer right = convertToRealValue(rightNumber);
			Integer result = left + right;
			
			StringBuilder all = new StringBuilder();
			int check = 0;
			
			int thousand = result / 1000;
			if (thousand > 0) {
				check = (thousand * 1000) - 5000;
				if (check < -1000) {
					for (int round = 0; round < thousand ; round++) {
						all.append("M");
					}
				} 
				result = result - (thousand * 1000);
			}
			
			int hundred = result / 100;
			if (hundred > 0) {
				check = (hundred * 100) - 500;
				if (check < -100) {
					for (int round = 0; round < hundred ; round++) {
						all.append("C");
					}
				} else if (check == -100) {
					all.append("CD");
				} else if (check >= 100) {
					all.append("D");
					for (int round = 0; round < (hundred-5) ; round++) {
						all.append("C");
					}
				}
				result = result - (hundred * 100);
			}
			
			int ten = result / 10;
			if (ten > 0) {
				check = (ten * 10) - 50;
				if (check < -10) {
					for (int round = 0; round < ten ; round++) {
						all.append("X");
					}
				} else if (check == -10) {
					all.append("XL");
				} else if (check >= 10) {
					all.append("L");
					for (int round = 0; round < (ten-5) ; round++) {
						all.append("X");
					}
				}
				result = result - (ten * 10);
			}
			
			if (result > 0) {
				check = result - 5;
				if (check < -1) {
					for (int round = 0; round < result ; round++) {
						all.append("I");
					}
				} else if (check == -1) {
					all.append("IV");
				} else if (check >= 0) {
					all.append("V");
					for (int round = 0; round < (result-5) ; round++) {
						all.append("I");
					}
				}
			}
			
			System.out.println(all.toString());
		}
	}
	
	private static List<String> readFileInput (String inputFile) {
		BufferedReader br = null;
		FileReader fr = null;
		List<String> allInput = new ArrayList<String>();

		try {

			fr = new FileReader(inputFile);
			br = new BufferedReader(fr);

			String sCurrentLine;

			while ((sCurrentLine = br.readLine()) != null) {
				allInput.add(sCurrentLine);
			}

		} catch (IOException e) {

			e.printStackTrace();

		} finally {

			try {

				if (br != null)
					br.close();

				if (fr != null)
					fr.close();

			} catch (IOException ex) {

				ex.printStackTrace();

			}

		}
		
		return allInput;
	}
	
	private static void retrieveAllRomanNumber () {
		romanNumber = new HashMap<String, Integer>();
		romanNumber.put("M", 1000);
		romanNumber.put("D", 500);
		romanNumber.put("C", 100);
		romanNumber.put("L", 50);
		romanNumber.put("X", 10);
		romanNumber.put("V", 5);
		romanNumber.put("I", 1);
	}
	
	private static boolean isOperator (char input) {
		if (input == ADD) {
			return true;
		}
		return false;
	}
	
	private static Integer convertToRealValue (List<Integer> romanValues) {
		
		Integer prior = null;
		List <Integer> toCalculates = new ArrayList<Integer>(romanValues);
		Integer returnNumber = 0;
		int index = 0; 
		for (Integer romanValue : romanValues) {
			if (romanValue == null) {
				index++;
				continue;
			}
			if (prior != null && prior < romanValue) {
				toCalculates.set(index-1, -romanValues.get(index-1));
			}
			prior = romanValue;
			index++;
		}
		for (Integer toCalculate : toCalculates) {
			if (toCalculate != null) {
				returnNumber += toCalculate;
			}
		}
		
		return returnNumber;
	}
	
	
}
